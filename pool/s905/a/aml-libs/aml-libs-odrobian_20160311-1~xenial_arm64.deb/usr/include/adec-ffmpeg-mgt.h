int RegisterDecode(aml_audio_dec_t *audec,int type);
