int audiodsp_get_pcm_level(dsp_operations_t* dsp_ops);
int audiodsp_init(dsp_operations_t *dsp_ops);
int audiodsp_start(aml_audio_dec_t *audec);
int audiodsp_stop(dsp_operations_t *dsp_ops);
int audiodsp_release(dsp_operations_t *dsp_ops);

