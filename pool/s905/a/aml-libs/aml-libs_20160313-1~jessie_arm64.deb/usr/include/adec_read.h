int uio_init(aml_audio_dec_t *audec);
