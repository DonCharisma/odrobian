int amdisplay_utils_get_osd_rotation();
