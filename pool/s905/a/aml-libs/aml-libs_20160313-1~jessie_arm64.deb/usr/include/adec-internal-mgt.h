int match_types(const char *filetypestr,const char *typesetting);
