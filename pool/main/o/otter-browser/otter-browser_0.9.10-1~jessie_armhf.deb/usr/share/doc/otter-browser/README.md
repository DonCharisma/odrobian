Otter Browser
=============

Project aiming to recreate the best aspects of the classic Opera (12.x) UI using Qt5
